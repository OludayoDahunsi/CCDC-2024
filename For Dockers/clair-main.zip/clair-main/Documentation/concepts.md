# Concepts

The following sections give a conceptual overview of how Clair works internally.

- [Internal API](./concepts/api_internal.md)
- [Authentication](./concepts/authentication.md)
- [Notifications](./concepts/notifications.md)
- [Updaters and Airgap](./concepts/updatersandairgap.md)
