# Contribuion
The following sections provides information on how to contribute to Clair.

- [Commit Style](./contribution/commit_style.md)
- [Releases](./contribution/releases.md)
