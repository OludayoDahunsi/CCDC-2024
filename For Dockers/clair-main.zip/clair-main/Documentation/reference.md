# Reference
The following sections provide reference information useful when exploring the documentation or working with Clair directly.

- [API](./reference/api.md)
- [Clairctl](./reference/clairctl.md)
- [Config](./reference/config.md)
- [Indexer](./reference/indexer.md)
- [Matcher](./reference/matcher.md)
- [Notifier](./reference/notifier.md)
