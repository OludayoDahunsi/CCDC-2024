# How Tos

The following sections provide instructions on accomplish specific goals in Clair.

- [API Definition](./howto/api.md)
- [Deployment Models](./howto/deployment.md)
- [Getting Started](./howto/getting_started.md)
- [Testing ClairV4](./howto/testing.md)
