Clair exports [metrics](./config.md#metrics) on the [introspection
port](./config.md#introspection_addr) in the Prometheus format.

The exact metrics exposed are not considered API (and so are subject to change
between releases) but should be well described. An up-to-date grafana dashboard
example is in `contrib/openshift/grafana`.
