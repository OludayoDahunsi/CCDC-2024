#!/bin/sh
set -e
# If anything specific for the quay.io Clair instance needs to happen, add that here.
exit 0
