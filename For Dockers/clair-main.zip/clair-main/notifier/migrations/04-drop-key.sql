-- Drop the key table, as all of its users have been removed.
DROP TABLE key;

