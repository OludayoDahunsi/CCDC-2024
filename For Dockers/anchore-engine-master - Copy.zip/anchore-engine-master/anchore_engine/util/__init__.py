RFC1123_TIME_FORMAT = "%a, %d %b %Y %H:%M:%S %Z"
