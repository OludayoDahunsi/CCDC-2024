from anchore_engine.services.apiext.api.helpers.image_content_response import (
    make_image_content_response,
)
