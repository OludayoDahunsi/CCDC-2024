# Generated from result['image']['imagedata']['analysis_report']['package_list']['pkgs.gems']

# though there are other gems in the image, they are all owned by the ruby-libs APK package, which means engine will ignore them
pkgs = {
    "/usr/lib/ruby/gems/2.7.0/specifications/bundler-2.1.4.gemspec": {
        "name": "bundler",
        "lics": ["MIT"],
        "versions": ["2.1.4"],
        "latest": "2.1.4",
        "origins": [
            "André Arko",
            "Samuel Giddins",
            "Colby Swandale",
            "Hiroshi Shibata",
            "David Rodríguez",
            "Grey Baker",
            "Stephanie Morillo",
            "Chris Morris",
            "James Wen",
            "Tim Moore",
            "André Medeiros",
            "Jessica Lynn Suttles",
            "Terence Lee",
            "Carl Lerche",
            "Yehuda Katz",
        ],
        "sourcepkg": "https://bundler.io",
        "files": [
            "exe/bundle",
            "exe/bundler",
        ],
    }
}
