package v2

const SchemaVersion = 2
