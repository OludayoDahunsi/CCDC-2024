package v5

const SchemaVersion = 5
