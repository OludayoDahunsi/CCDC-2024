package v1

const SchemaVersion = 1
