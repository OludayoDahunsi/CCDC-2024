package v4

const SchemaVersion = 4
