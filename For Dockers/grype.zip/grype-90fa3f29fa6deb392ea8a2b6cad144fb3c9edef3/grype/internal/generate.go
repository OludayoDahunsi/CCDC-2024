package internal

//go:generate go run ./packagemetadata/generate/main.go
