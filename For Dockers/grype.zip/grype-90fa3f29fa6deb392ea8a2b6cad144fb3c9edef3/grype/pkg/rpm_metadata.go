package pkg

type RpmMetadata struct {
	Epoch           *int   `json:"epoch"`
	ModularityLabel string `json:"modularityLabel"`
}
