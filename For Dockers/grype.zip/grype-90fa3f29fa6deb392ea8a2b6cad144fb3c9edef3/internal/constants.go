package internal

// note: do not change this
const DBUpdateURL = "https://toolbox-data.anchore.io/grype/databases/listing.json"
