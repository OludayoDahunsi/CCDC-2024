package internal

const (
	NotProvided = "[not provided]"
)
