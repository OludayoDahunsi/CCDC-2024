---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**What happened**:

**What you expected to happen**:

**Steps to reproduce the issue**:

**Anything else we need to know?**:

**Environment**:
- Output of `syft version`:
- OS (e.g: `cat /etc/os-release` or similar):
