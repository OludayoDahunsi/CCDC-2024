package file

type Digest struct {
	Algorithm string `json:"algorithm"`
	Value     string `json:"value"`
}
