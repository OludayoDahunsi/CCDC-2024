package file

import "github.com/anchore/stereoscope/pkg/file"

type Metadata = file.Metadata
