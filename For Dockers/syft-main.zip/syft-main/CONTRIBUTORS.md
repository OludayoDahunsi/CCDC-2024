# Syft Contributors

The following Syft components were contributed by external authors/organizations.

## GraalVM Native Image

A cataloger contributed by Oracle Corporation that extracts packages given within GraalVM Native Image SBOMs.

## Swift Package Manager

A cataloger contributed by Axis Communications that catalogs packages resolved by Swift Package Manager.