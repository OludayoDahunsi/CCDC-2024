/*
Package internal contains miscellaneous functions and objects useful within syft but should not be used externally.
*/
package internal
